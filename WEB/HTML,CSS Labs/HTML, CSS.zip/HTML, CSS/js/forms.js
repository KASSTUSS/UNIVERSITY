let COUNTRY_CODE = "+375";

$(function(){
    $("#phone_number").mask(COUNTRY_CODE+" (99) 999-99-99");
});