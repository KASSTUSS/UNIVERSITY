let userBut = document.getElementById("user_button");
let regLogMenu = document.getElementById("log_reg_switcher_menu");
let isActive = false;

let hideMenu = function() {
    isActive = false;
    regLogMenu.style.display = "none";
    setTimeout(function(){
        regLogMenu.classList.add("hidden");
        userBut.classList.remove("focus");
    },1);
};

let showMenu = function() {
    isActive = true;
    regLogMenu.style.display = "block";
    setTimeout(function(){
        regLogMenu.classList.remove("hidden");
        userBut.classList.add("focus");
    },1);
}

userBut.addEventListener("click", function(){
    if(isActive) {
        hideMenu();
    } else {
        showMenu();
    }
});

document.addEventListener("click", function(){
    if(isActive) {
        //hideMenu();
    }
});