let inputSearch = document.getElementById("search_input");
let buttonSearch = document.getElementById("search_button");

let isActiveSearch = false;

let hideSearchInput = function() {
    isActiveSearch = false;
    inputSearch.style.display = "none";
    setTimeout(function(){
        inputSearch.classList.add("hidden_search_input");
        buttonSearch.classList.remove("focus");
    },1);
};

let showSearchInput = function() {
    isActiveSearch = true;
    inputSearch.style.display = "block";
    setTimeout(function(){
        inputSearch.classList.remove("hidden_search_input");
        buttonSearch.classList.add("focus");
    },1);
}

buttonSearch.addEventListener("click", function(){
    if(isActiveSearch) {
        hideSearchInput();
    } else {
        showSearchInput();
    }
});