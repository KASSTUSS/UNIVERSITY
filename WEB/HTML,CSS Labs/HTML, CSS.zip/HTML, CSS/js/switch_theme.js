function getCookie(name) {
    let matches = document.cookie.match(new RegExp(
      "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
}

function setCookie(name, value, options = {}) {

    options = {
      path: '/',
      ...options
    };
  
    if (options.expires instanceof Date) {
      options.expires = options.expires.toUTCString();
    }
  
    let updatedCookie = encodeURIComponent(name) + "=" + encodeURIComponent(value);
  
    for (let optionKey in options) {
      updatedCookie += "; " + optionKey;
      let optionValue = options[optionKey];
      if (optionValue !== true) {
        updatedCookie += "=" + optionValue;
      }
    }
  
    document.cookie = updatedCookie;
}

let themeSwitcherElem = document.getElementById("theme_switch");
var isDarkModeOn;

// themeSwitcherElem.addEventListener('change', function () {
//     this.value = this.checked ? '1' : '0';
// });

function themeSwitcherMode() {
    if(getCookie("isDarkModeOn") == "true") {
        document.body.style.setProperty('--font-color', 'var(--bg-ligth-color)');
        document.body.style.setProperty('--bg-color', 'var(--main-dark-color)');
        document.body.style.setProperty('--line-color', 'var(--dark-gray-color)');
        document.body.style.setProperty('--content-bg-color', 'var(--dark-content-bg-color)');
        document.body.style.setProperty('--content-block-bg-color', 'var(--dark-color-content-block)');
        document.body.style.setProperty('--price-block-bg-color', 'var(--dark-gray-color)');

        document.getElementById("sun_and_moon").classList.add("dark_mode_on");
         
    } else {
        document.body.style.setProperty('--font-color', 'var(--main-dark-color)');
        document.body.style.setProperty('--bg-color', 'var(--bg-ligth-color)');
        document.body.style.setProperty('--line-color', 'var(--light-gray-color)');
        document.body.style.setProperty('--content-bg-color', 'var(--light-content-bg-color)');
        document.body.style.setProperty('--content-block-bg-color', 'var(--bg-ligth-color)');
        document.body.style.setProperty('--price-block-bg-color', 'var(--light-gray-p-color)');

        document.getElementById("sun_and_moon").classList.remove("dark_mode_on");
    }
}

themeSwitcherElem.addEventListener("change", function() {
    if(themeSwitcherElem.checked) 
        isDarkModeOn = true;
    else
        isDarkModeOn = false;
    
    setCookie("isDarkModeOn", isDarkModeOn);
    console.log(getCookie("isDarkModeOn") + "   " + isDarkModeOn);
    
    themeSwitcherMode();
});

document.addEventListener("DOMContentLoaded", function() {
    themeSwitcherMode();

    if(getCookie("isDarkModeOn") == "true") {
        themeSwitcherElem.value = 1;
        themeSwitcherElem.checked = true;
    }
    else{
        themeSwitcherElem.value = 0;
        themeSwitcherElem.checked = false;
    }
});